﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int chance = 3;

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string useriddeclare = "1";
            string passworddeclare = "admin123";
            string useridInput = userid.Text;
            string passwordInput = password.Text;
            if (useriddeclare.Equals(useridInput) && passworddeclare.Equals(passwordInput))
            {
                MessageBox.Show("Welcome User");
                
            }
            else
            {
                userid.Text = "";
                password.Text = "";
                chance--;
                MessageBox.Show("Invalid Credentials. You have " + chance + " chance(s) left.");
                if (chance == 0)
                {
                    MessageBox.Show("Maximum login attempts reached. Please try again later.");
                    this.Close();
                }
            }
        }

    }
}
